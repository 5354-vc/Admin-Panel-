package com.mycompany.servlets;

import com.mycompany.util.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/updateUser")
public class UpdateUserServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String username = request.getParameter("username");
        String email = request.getParameter("email");

        try (Connection conn = DBConnection.getConnection()) {
            String query = "UPDATE users SET username=?, email=? WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, email);
            ps.setInt(3, id);
            ps.executeUpdate();
            response.sendRedirect("admin.html");
        } catch (Exception e) {
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}